import { Component, OnInit } from '@angular/core';
import { Router } from '../../../node_modules/@angular/router';
import { ItemService } from '../services/itemservice';
import{ Addproducts }from '../model/registermodel'

@Component({
  selector: 'app-additem',
  templateUrl: './additem.component.html',
  styleUrls: ['./additem.component.css']
})
export class AdditemComponent implements OnInit {
 url: string=''
 item:Addproducts
  constructor(private rt:Router,private is:ItemService) { 
    this.item=new Addproducts();
  }
  SaveItem(itemForm){
    if(itemForm.valid){
       this.item.image = this.item.image.replace('data:image/jpeg;base64,','')
       this.item.image = this.item.image.replace('data:image/jpg;base64,','')
       this.item.image = this.item.image.replace('data:image/png;base64,','')
       console.log(this.item.status)
     console.log(JSON.stringify(this.item))
     this.is.addItem(this.item).subscribe(
       (data)=>{console.log(data);
        alert(JSON.stringify(data))
        this.rt.navigate(['galleryAuctions']) 
        }
      )
     }
  }

  fileSelect(event){
     if(event.target.files){
       var reader  = new FileReader();
       reader.readAsDataURL(event.target.files[0]);
       reader.onload = (ev:any)=>{
         this.url = ev.target.result
         this.item.image = reader.result
       }
     }
  }

  ngOnInit() {
  }

}
