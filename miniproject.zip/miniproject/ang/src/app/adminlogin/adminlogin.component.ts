import { Component, OnInit } from '@angular/core';
import { adminlogin} from '../model/registermodel';
import { Router } from '../../../node_modules/@angular/router';
import { ItemService } from '../services/itemservice';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {
  aobj:adminlogin
  constructor(private is:ItemService,private rt:Router) {
    this.aobj = new adminlogin();
   }

   btnfun(ui,psw){
   
     this.is.adminlogin(ui,psw).subscribe((data)=>{
      
       if(data.length>0){
         localStorage.setItem('adminid',this.aobj.adminid)
        this.rt.navigate(['home'])
       }
     })
   }

  ngOnInit() {
  }

}