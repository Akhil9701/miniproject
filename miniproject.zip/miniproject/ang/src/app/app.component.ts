import { Component,DoCheck } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Router } from '../../node_modules/@angular/router';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements DoCheck {
  localval:Observable<any>
  adminval:Observable<any>
  constructor(private rt:Router){}

  CheckLocalStore(): Observable<any> {
    return of(localStorage.getItem("uid"));

}
CheckLocalStoreadm(): Observable<any> {
  return of(localStorage.getItem("adminid"));

}
logOutClick()
{
    localStorage.removeItem("uid");
    this.rt.navigate(['login']);
    
    localStorage.removeItem("adminid")
    this.rt.navigate(['home'])
    
}
ngDoCheck() {  
  this.CheckLocalStore().subscribe((data) => { this.localval = data })
  this.CheckLocalStoreadm().subscribe((data)=>{this.adminval =  data})
}
}
