import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { ContactusComponent } from './contactus/contactus.component';
import { AboutusComponent } from './aboutus/aboutus.component';

import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { GalleryauctionsComponent } from './galleryauctions/galleryauctions.component';
import { HttpClientModule } from '@angular/common/http';
import { AdditemComponent } from './additem/additem.component';
import { ItemdetailsComponent } from './itemdetails/itemdetails.component';
import { CartComponent } from './cart/cart.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { MyproductsComponent } from './myproducts/myproducts.component';
import { ItemlistComponent } from './itemlist/itemlist.component';
import { BidwinnerComponent } from './bidwinner/bidwinner.component'


var myRoutes: Routes = [
  { path: 'home', component: HomeComponent },
  {path:'cart',component:CartComponent},
  { path: 'addItem', component: AdditemComponent },
  { path: 'aboutUs', component: AboutusComponent },
  { path: 'contactUs', component: ContactusComponent },
  { path: 'galleryAuctions', component: GalleryauctionsComponent },
  {path:'itemdetails/:pid',component:ItemdetailsComponent},
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  {path:'adminlogin',component:AdminloginComponent},
  {path:'itemlist',component:ItemlistComponent},
  {path:'myproducts',component:MyproductsComponent},
  {path:'bidwinner',component:BidwinnerComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ContactusComponent,
    AboutusComponent,
    
    LoginComponent,
    RegisterComponent,
    GalleryauctionsComponent,
    AdditemComponent,
    ItemdetailsComponent,
    CartComponent,
    AdminloginComponent,
    MyproductsComponent,
    ItemlistComponent,
    BidwinnerComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(myRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
