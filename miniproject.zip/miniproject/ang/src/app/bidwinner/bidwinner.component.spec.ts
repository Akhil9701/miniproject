import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BidwinnerComponent } from './bidwinner.component';

describe('BidwinnerComponent', () => {
  let component: BidwinnerComponent;
  let fixture: ComponentFixture<BidwinnerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BidwinnerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BidwinnerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
