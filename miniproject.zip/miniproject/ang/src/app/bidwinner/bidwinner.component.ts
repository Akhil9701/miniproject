import { Component, OnInit, ModuleWithComponentFactories } from '@angular/core';
import { ItemService } from '../services/itemservice';
import{winner} from '../model/registermodel';

@Component({
  selector: 'app-bidwinner',
  templateUrl: './bidwinner.component.html',
  styleUrls: ['./bidwinner.component.css']
})
export class BidwinnerComponent implements OnInit {
  bwobj:winner
  constructor(
    private is:ItemService) {
      this.bwobj= new winner();
     }
     btnaccept(cpid,cuid,cmoney){
       this.is.winnercfm(cpid,cuid,cmoney).subscribe((data)=>{
         this.is.lossercfm(cpid,cuid,cmoney).subscribe((data)=>{
           console.log(data)
         })
       })
       this.is.winnersts(cpid).subscribe((data)=>{

       })
       location.reload();
     }
    

  ngOnInit() {
    this.is.winner().subscribe((data)=>{
      this.bwobj=data
      console.log(this.bwobj)
    })
  }

}
