import { Component, OnInit } from '@angular/core';
import { usercart } from '../model/registermodel'
import { ItemService } from '../services/itemservice';
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  ccObj:usercart
  constructor(private is:ItemService) { 
    this.ccObj=new usercart();
  }

  ngOnInit() {
    var i=localStorage.getItem('uid')
    this.is.usercart(i).subscribe((data)=>{
      this.ccObj=data;
      console.log(this.ccObj)
    })
  }

}
