import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GalleryauctionsComponent } from './galleryauctions.component';

describe('GalleryauctionsComponent', () => {
  let component: GalleryauctionsComponent;
  let fixture: ComponentFixture<GalleryauctionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GalleryauctionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GalleryauctionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
