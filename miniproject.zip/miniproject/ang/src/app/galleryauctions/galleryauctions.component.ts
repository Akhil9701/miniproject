import { Component, OnInit, DoCheck } from '@angular/core';
import { ItemService } from '../services/itemservice';
import { Router } from '../../../node_modules/@angular/router';
import { Observable, of } from 'rxjs';

@Component({
  selector: 'app-galleryauctions',
  templateUrl: './galleryauctions.component.html',
  styleUrls: ['./galleryauctions.component.css']
})
export class GalleryauctionsComponent implements OnInit,DoCheck {
  localval:Observable<any>
  products:any[]=[]
  constructor(private is:ItemService,private rt:Router) { }

  private checkLogin():Observable<any>{
    return of( localStorage.getItem('uid'))
    }
  // btnDelClick(pid){
  //   this.is.deleteProduct(pid).subscribe(
  //     (data)=>{alert(JSON.stringify(data))
  //     this.ngOnInit();
  //     }
      
  //   )
  // }
  btnBidClick(pid){
    alert("you need to login")
    this.rt.navigate(['login'])
  }
  btnBidsClick(pid){
    
    this.rt.navigate(['itemdetails/'+pid])
  }
  ngOnInit() {
    this.is.getAllProducts().subscribe((res) => {
      console.log(res)
      this.products = res
      
    })
  }

ngDoCheck(){
  this.checkLogin().subscribe((data)=>{
    this.localval=data
})

  }
}
