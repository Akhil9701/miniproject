import { Component, OnInit } from '@angular/core';
import { galleryauctions, cart, userbids, tl } from '../model/registermodel';
import { ActivatedRoute, Router } from '../../../node_modules/@angular/router';
import { ItemService } from '../services/itemservice';


@Component({
  selector: 'app-itemdetails',
  templateUrl: './itemdetails.component.html',
  styleUrls: ['./itemdetails.component.css']
})
export class ItemdetailsComponent implements OnInit {
 gaObj:galleryauctions
 cObj:cart
 bidObj:userbids
 tlObj:tl
  constructor(private ar:ActivatedRoute,private is:ItemService,private rt:Router) {
    this.gaObj=new galleryauctions();
    this.cObj=new cart();
    this.bidObj=new userbids();
    this.tlObj=new tl();
   }
   btnbid(pid,bid){
    this.cObj.cuid = localStorage.getItem('uid');
    this.cObj.cpid = pid;
    this.cObj.cmoney = bid;
    
    this.is.addcarttbl(this.cObj).subscribe((data)=>{
  this.rt.navigate(['cart'])
    })
  }

  ngOnInit() {
    var i = parseInt(this.ar.snapshot.params["pid"])
   
    this.is.getproductbyid(i).subscribe((data)=>{
     
      this.gaObj=data;
      
    this.is.userbids(i).subscribe((data)=>{
      this.tlObj = data
      console.log(JSON.stringify(data))
    })
    })
  }

}
