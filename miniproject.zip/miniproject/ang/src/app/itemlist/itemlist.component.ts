import { Component, OnInit } from '@angular/core';
import{itemdetails} from '../model/registermodel'
import { ItemService } from '../services/itemservice';

@Component({
  selector: 'app-itemlist',
  templateUrl: './itemlist.component.html',
  styleUrls: ['./itemlist.component.css']
})
export class ItemlistComponent implements OnInit {

  pdobj:itemdetails
  constructor(private is:ItemService) { 

    this.pdobj=new itemdetails();
  }

  btnapprove(pid){
    this.is.adminapprov(pid).subscribe((data)=>{
      location.reload();
    })
  }
  btndecline(pid){
    this.is.admindecline(pid).subscribe((data)=>{
      location.reload();
    })
  }

  ngOnInit() {
 this.is.itemdetails().subscribe((data)=>{
  this.pdobj=data
  console.log(data)
 
})

  }

}