import { Component, OnInit } from '@angular/core';
import { Router } from '../../../node_modules/@angular/router';
import { ItemService } from '../services/itemservice';
import { Register } from '../model/registermodel';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
login:Register

  constructor(private rt:Router,private is:ItemService) { 
    this.login=new Register();

  }

  btnLoginClick(u,p) {

    this.is.CheckLogin(u, p).subscribe((data) => {
      
        if (data.length > 0) {
          alert('Login succesfull.....')
            localStorage.setItem("uid", u)
            this.rt.navigate(['home'])
        }
        else {
            alert('Invalid User...You need to signup')
        }
    })
}

  ngOnInit() {
  }

}
