export class Register{
    uid:number
    firstname:string
    lastname:string
    emailid:string
    password:string
    image:any
    mobile:number
    
}
export class galleryauctions{
    uid:string
    pid:number
    pname:string    
    baseprice:string
    image:any
    auctionenddate:Date
    description:string
    status:string
}

export class Addproducts{
    pid:number
    pnmae:string
    baseprice:string
    image:any
    auctionenddate:Date
    description:string
    status:string='pending'
}

export class cart{
    cuid:string
    cpid:number
    cmoney:number
    status:string='pending'
}
export class usercart{
    pid:string
    pname:string
    baseprice:string
    image:string
    cmoney:number
    status:string
}
export class userbids{
    firstname:string
    cmoney:number
}

export class tl{
    firstname:string
    cmoney:number
}

export class adminlogin{
    adminid:string
    vpassword:string
}

export class myproducts{
    pname:string
    image:any
    baseprice:string
    status:string
}

export class itemdetails{
    pid:number
    pname:string
    baseprice:string
    auctionenddate:string
    image:any
}
export class winner{
    cpid:string
    cuid:string
    cmoney:number
}