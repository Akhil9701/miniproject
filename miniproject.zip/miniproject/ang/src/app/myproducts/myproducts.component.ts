import { Component, OnInit } from '@angular/core';
import { ItemService } from '../services/itemservice';
import{myproducts} from '../model/registermodel'
@Component({
  selector: 'app-myproducts',
  templateUrl: './myproducts.component.html',
  styleUrls: ['./myproducts.component.css']
})
export class MyproductsComponent implements OnInit {

  mobj:myproducts
  constructor(private is:ItemService) { 
    this.mobj= new myproducts();
  }

  ngOnInit() {
    var i = localStorage.getItem('uid')
   
    this.is.myproducts(i).subscribe((data)=>{
      console.log(JSON.stringify(data))
      this.mobj=data;
    })
  }

}