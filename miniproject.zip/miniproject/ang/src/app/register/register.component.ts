import { Component, OnInit } from '@angular/core';
import{Register} from '../model/registermodel'
import { Router } from '@angular/router';
import { ItemService } from '../services/itemservice';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  url:string=''
  reg:Register
  constructor(private rt:Router,private is:ItemService) {
    this.reg = new Register();
  }
  btnSubmitClick(regForm) {
    let frmValid: boolean
    frmValid = regForm.valid
    if (frmValid == true)
      alert('Form Submitted to the server ....')
    else
      alert("Invalid Form .. ")
  }
  fileSelect(event) {
    if (event.target.files) {
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (ev: any) => {
        this.url = ev.target.result
        this.reg.image = reader.result
      }
    }
  }

  funsubmit(regForm){
    if(regForm.valid){
      this.is.register(this.reg).subscribe((data)=>{
        this.rt.navigate(['login'])
      })
    }
  }
    ngOnInit() {
    }

  }
