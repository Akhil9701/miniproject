import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { Observable } from 'rxjs';
import { Register, Addproducts } from '../model/registermodel'
@Injectable({
  providedIn: 'root'
})
export class ItemService {
  apiUrl: string = "http://localhost:4601/register";
  apiUrll: string = "http://localhost:4601/addproducts";
  apiUrlll: string = "http://localhost:4601/cart";
  userapi: string = "http://localhost:4601/user";
  adminapi: string = "http://localhost:4601/adminlogin";
  userprod: string = "http://localhost:4601/mani";
  akl: string = "http://localhost:4601/akhil";
  myprod: string = "http://localhost:4601/myproducts";
  winapi: string = "http://localhost:4601/winner";
  winsapi: string = "http://localhost:4601/winners";
  losapi: string = "http://localhost:4601/loser";

  constructor(private ht: HttpClient) { }


  register(regObj: Register): Observable<any> {
    const headers = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.ht.post(this.apiUrl, JSON.stringify(regObj), headers)
  }
  getAllProducts(): Observable<any> {
    return this.ht.get(this.akl, { responseType: 'json' })
  }
  deleteProduct(pid: number): Observable<any> {
    return this.ht.delete(this.apiUrll + '/' + pid, { responseType: 'json' })
  }
  addItem(pObj: Addproducts): Observable<any> {
    const hdrOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.ht.post(this.apiUrll, JSON.stringify(pObj), hdrOptions)
  }
  addcarttbl(cObj): Observable<any> {
    const hdrOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.ht.post(this.apiUrlll, JSON.stringify(cObj), hdrOptions)
  }
  itemdetails(): Observable<any> {
    return this.ht.get(this.userprod, { responseType: 'json' })
  }
  getproductbyid(i): Observable<any> {
    return this.ht.get(this.apiUrll + '/' + i, { responseType: 'json' })
  }
  userbids(i): Observable<any> {
    return this.ht.get(this.userapi + '/' + i, { responseType: 'json' })
  }
  usercart(i): Observable<any> {
    return this.ht.get(this.apiUrlll + '/' + i, { responseType: 'json' })
  }
  adminlogin(id, pwd): Observable<any> {
    return this.ht.get(this.adminapi + '/' + id + '/' + pwd, { responseType: 'json' })
  }

  adminapprov(i): Observable<any> {
    const headerop = {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    }
    return this.ht.put(this.userapi + '/' + i, headerop)
  }
  admindecline(i): Observable<any> {
    const headerop = {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    }
    return this.ht.put(this.adminapi + i, headerop)
  }
  myproducts(i): Observable<any> {
    return this.ht.get(this.myprod + '/' + i, { responseType: 'json' })
  }

  CheckLogin(ui: string, p: string): Observable<any> {

    return this.ht.get('http://localhost:4601/register/' + ui + '/' + p, { responseType: 'json' });
  }

  winner(): Observable<any> {
    return this.ht.get(this.winapi, { responseType: 'json' })
  }
  winnercfm(cpid, cuid, cmoney): Observable<any> {
    const headerop = {
      headers: new HttpHeaders({ 'Content-type': 'application/json' })
    }
    return this.ht.put(this.winapi + '/' + cpid + '/' + cuid + '/' + cmoney, headerop)
  }
  winnersts(cpid): Observable<any> {
    const headerop = {
      headers: new HttpHeaders({ 'Content-type': 'application/json' })
    }
    return this.ht.put(this.winsapi + '/' + cpid, headerop)
  }
  lossercfm(cpid, cuid, cmoney): Observable<any> {
    const headerop = {
      headers: new HttpHeaders({ 'Content-type': 'application/json' })
    }
    return this.ht.put(this.losapi + '/' + cpid + '/' + cuid + '/' + cmoney, headerop)
  }
}

