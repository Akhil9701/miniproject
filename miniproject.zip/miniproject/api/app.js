var fs = require('fs')
var path = require('path')
var bodyparser = require('body-parser')
var express = require('express')
var promise = require('bluebird')

var app = express();
var options = { promiseLib: promise }

var pgp = require('pg-promise')(options)
var cs = 'postgres://postgres:root@localhost:5432/sampleproject'

var db = pgp(cs)

app.set('port', process.env.PORT || 4601)

app.use(bodyparser.json({ limit: "50mb" }));
app.use(bodyparser.urlencoded({ limit: "50mb", extended: true, parameterLimit: 50000 }));


app.use(function (req, res, next) {

    res.setHeader('Access-Control-Allow-Origin', '*');


    res.setHeader('Access-Control-Allow-Methods', '*');


    res.setHeader('Access-Control-Allow-Headers', '*');


    res.setHeader('Access-Control-Allow-Credentials', true);


    next();
});

app.use(express.static(path.join(__dirname, 'images')))

app.get('/', (req, res) => {
    res.send('Database coinnectivity Ex.....')
})
//==============================================REGISTER API============================================
app.get('/register', (req, res, next) => {
    db.any('select * from  register').then(
        (data) => {
            res.send(data)
        })
})

app.post('/register', (req, res, next) => {

    console.log(req.body.firstname)
    var fileName = req.body.uid + '.png'
    var cfn = path.join(__dirname, 'images/' + fileName)
    fs.writeFile(cfn, req.body.image, 'base64', (err) => {
        if (err)
            console.log('unable to save image')
        else
            console.log('image saved success')

    })
    var i = parseInt(req.body.uid)
    var n = req.body.firstname
    var l = req.body.lastname
    var e = req.body.emailid
    var pw = req.body.password
    var im = "http://localhost:4601/" + req.body.uid + '.png'
    var m = req.body.mobile
    db.any('insert into register values($1,$2,$3,$4,$5,$6,$7)', [i, n, l, e, pw, im, m]).then(
        (data) => {
            res.send({ 'message': 'Saved Successssssss...' })
        }
    )
})



app.get('/register/:uid/:password', (req, res, next) => {
    var ui = req.params.uid
    var p = req.params.password
    console.log(ui + " " + p);
    db.any('select * from register where uid=$1 and password=$2', [ui, p])
        .then((data) => {
            res.send(data)
        })

})



//==============================================ADDPRODUCTS API=====================================================
app.post('/addproducts', (req, res, next) => {
    console.log(req.body)
    var fileName = req.body.pid + '.png'
    var cfn = path.join(__dirname, 'images/' + fileName)
    fs.writeFile(cfn, req.body.image, 'base64', (err) => {
        console.log(req.body.image)
        if (err)
            console.log('unable to save image')
        else
            console.log('image saved success')

    })
    
    var i = parseInt(req.body.pid)
    var n = req.body.pname
    var p = req.body.baseprice
    var im = "http://localhost:4601/" + req.body.pid + '.png'
    var d = req.body.auctionenddate
    var pd = req.body.description
    var s = 'pending';
    var ui=req.body.uid
    db.any('insert into addproducts values($1,$2,$3,$4,$5,$6,$7,$8)', [i, n, p, im, d, pd,s,ui]).then(
        (data) => {
            res.send({ 'message': 'Saved Successssssss...' })
        }
    )
})


// app.get('/addproducts', (req, res, next) => {
    
//     db.any('select * from addproducts').then(
//         (data) => {
//             res.send(data)
//         })
// })



app.delete('/addproducts/:pid',(req,res,next)=>{
    var ppid = req.params.pid
    db.any('delete from addproducts where pid = $1', ppid). then(
        (data)=>{
            res.send({'message':'Record Deleted Successsssss'})
        }
    )
})

app.get('/addproducts/:pid', (req, res, next) => {
    
    ppid = req.params.pid
    
    db.any('select * from addproducts where pid = $1', ppid).then(
        (data) => {
            res.send(data)
        })
})



app.get('/myproducts/:uid',(req,res,next)=>{
    var id = req.params.uid

    db.any("select  * from addproducts where uid = $1",id).then((data)=>{
        res.send(data);
    })
})
//admin pending status
app.get('/mani', (req, res, next) => {

    db.any("select * from addproducts where status ='pending'").then((data) => {
        res.send(data)
    })
})
//to update status to pending to active
app.get('/akhil', (req, res, next) => {

    db.any("select * from addproducts where status ='active'").then((data) => {
        res.send(data)
    })
})
//to update status to pending to inactive
app.get('/addproductss', (req, res, next) => {

    db.any("select * from addproducts where status ='inactive'").then((data) => {
        res.send(data)
    })
})


//display the name and amount from particular product
app.get('/user/:pid', (req, res, next) => {
    var id = req.params.pid
    db.any("select firstname,cmoney from register r inner join cart c on r.uid=c.cuid inner join addproducts ap on ap.pid=c.cpid where ap.pid=$1", id).then((data) => {
        res.send(data)
    })
})
//after bidding cart details
app.get('/cart/:cuid', (req, res, next) => {
    var id = req.params.cuid
    console.log(id)
    db.any("select pid,pname,baseprice,cmoney,c.status from register r inner join cart c on r.uid=c.cuid inner join addproducts ap on ap.pid=c.cpid where r.uid=$1", id).then((data) => {
        res.send(data)
    })
})

//after clicking the bid

// app.get('/cart/:pid',(req,res,next)=>{
//     var ppid=req.params.pid
//     db.any("select * from addproducts where pid=$1",ppid).then((data)=>{
//         res.send(data)
//     })
// })






//=============================================CART API================================================  
app.post('/cart', (req, res, next) => {
    var i =req.body.cuid
    var p = req.body.cpid
    var m = req.body.cmoney
    var s = req.body.status
    db.any('insert into cart values($1,$2,$3,$4)', [i, p, m,s]).then(
        (data) => {
            res.send({ 'message': 'Saved Successssssss...' })
        }
    )
})
// //querry to particular user which product was add.
// app.get('/carts/:pid', (req, res, next) => {
//     var uid = req.params.uid
//     var pid = req.params.pid
//     db.any("select uid, pid,pname,baseprice,cmoney from register r inner join cart c on r.uid=c.cuid inner join addproducts ap on ap.pid=c.cpid where pid=$1", pid).then((data) => {
//         res.send(data)
//     })
// })

//admin login page
app.get('/adminlogin/:aid/:pwd',(req,res,next)=>{
    var id = req.params.aid
    var p =req.params.pwd

    db.any("select * from adminlogin where adminid =$1 and vpassword = $2",[id,p]).then((data)=>{
        res.send(data)
    })

})





//admin accept the product

app.put('/user/:pid',(req,res,next)=>{
    var id= req.params.pid
    db.any("update addproducts set status ='active' where pid=$1",id).then((data)=>{
        res.send(data)
    })
})
//admin decline the product
app.put('/admin/:pid',(req,res,next)=>{
    var id= req.params.pid
    db.any("update addproducts set status ='decline' where pid=$1",id).then((data)=>{
        res.send(data)
    })
})


//winner
app.get('/winner',(req,res,next)=>{
    var p= req.params.cpid;
 db.any("select max(cmoney),cpid,cuid,status from cart group by cuid, cpid,status having  status='pending'",p).then((data)=>{
     res.send(data)
 })
 })




app.put('/winner/:cpid/:cuid/:cmoney',(req,res,next)=>{
    var p = req.params.cpid
    var u = req.params.cuid
    var c = req.params.cmoney
    console.log(p+u+c)
    db.any("update cart set status ='winner' where cpid=$1 and cuid=$2 and cmoney=$3",[p,u,c]).then((data)=>{
        res.send(data)
    })

})


app.put('/loser/:cpid/:cuid/:cmoney',(req,res,next)=>{
    var p = req.params.cpid
    var u = req.params.cuid
    var c = req.params.cmoney
    db.any("update cart set status ='lost' where cpid=$1 and status='pending' ",[p]).then((data)=>{
        res.send(data)
    })

})



app.put('/winners/:cpid', (req, res, next) => {

    var id = req.params.c
    pid
    db.any("update addproducts set status ='completed' where cpid=$1 ", id).then((data) => {
        res.send(data)
    })
})


app.listen(app.get('port'), (err) => {
    if (err)
        console.log('server not started')
    else
        console.log('server Started at  : http://localhost:4601')
})